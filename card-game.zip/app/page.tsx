"use client"

import { useState } from "react"
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui"
import { useWallet } from "@solana/wallet-adapter-react"
import { WalletContextProvider } from "./components/wallet-provider"
import UserInfo from "./components/user-info"
import CardGallery from "./components/card-gallery"
import PlayersList from "./components/players-list"
import GameLog from "./components/game-log"
import CardSelectorModal from "./components/card-selector-modal"
import { Layers, Package, Zap } from "lucide-react"

export default function Home() {
  return (
    <WalletContextProvider>
      <CardGameApp />
    </WalletContextProvider>
  )
}

function CardGameApp() {
  const { connected, publicKey } = useWallet()
  const [activeTab, setActiveTab] = useState("latest")
  const [isCardSelectorOpen, setIsCardSelectorOpen] = useState(false)
  const [targetSelf, setTargetSelf] = useState(false)

  // Current SOL price for booster pack
  const boosterPackPrice = 0.05

  const handlePlayCardOnSelf = () => {
    setTargetSelf(true)
    setIsCardSelectorOpen(true)
  }

  const handleSelectCard = (cardId: number) => {
    // In a real app, you would implement the logic to play the card
    console.log(`Playing card ${cardId} on ${targetSelf ? "self" : "target"}`)
    setIsCardSelectorOpen(false)
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border/40 p-4">
        <div className="container mx-auto flex items-center justify-between">
          <h1 className="text-xl font-light tracking-wider text-primary">
            <span className="font-normal">SOLANA</span> CARD GAME
          </h1>
          <div className="wallet-adapter-button-container">
            <WalletMultiButton />
          </div>
        </div>
      </header>

      <main className="container mx-auto p-4">
        {connected && publicKey ? (
          <>
            <UserInfo publicKey={publicKey.toString()} />

            <div className="my-6">
              <div className="mb-6 flex flex-wrap gap-3">
                <button
                  className={`action-button flex items-center gap-2 rounded-lg px-4 py-2 ${
                    activeTab === "latest"
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  }`}
                  onClick={() => setActiveTab("latest")}
                >
                  <Layers className="h-4 w-4" />
                  <span>Latest Cards</span>
                </button>
                <button
                  className={`action-button flex items-center gap-2 rounded-lg px-4 py-2 ${
                    activeTab === "all"
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  }`}
                  onClick={() => setActiveTab("all")}
                >
                  <Layers className="h-4 w-4" />
                  <span>All Cards</span>
                </button>
                <button className="action-button flex items-center gap-2 rounded-lg bg-secondary px-4 py-2 text-secondary-foreground hover:bg-secondary/80">
                  <Package className="h-4 w-4" />
                  <span>Buy Pack ({boosterPackPrice} SOL)</span>
                </button>
                <button
                  className="action-button flex items-center gap-2 rounded-lg bg-secondary px-4 py-2 text-secondary-foreground hover:bg-secondary/80"
                  onClick={handlePlayCardOnSelf}
                >
                  <Zap className="h-4 w-4" />
                  <span>Play on Self</span>
                </button>
              </div>

              <CardGallery showAll={activeTab === "all"} />
            </div>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <PlayersList
                onPlayCard={() => {
                  setTargetSelf(false)
                  setIsCardSelectorOpen(true)
                }}
              />
              <GameLog />
            </div>

            <CardSelectorModal
              isOpen={isCardSelectorOpen}
              onClose={() => setIsCardSelectorOpen(false)}
              onSelectCard={handleSelectCard}
              targetName={targetSelf ? "Yourself" : undefined}
            />
          </>
        ) : (
          <div className="flex h-[70vh] flex-col items-center justify-center">
            <h2 className="mb-6 text-2xl font-light tracking-wider text-primary">WELCOME TO SOLANA CARD GAME</h2>
            <p className="mb-8 text-center text-muted-foreground">
              Connect your Phantom wallet to start playing and view your cards.
            </p>
            <WalletMultiButton />
          </div>
        )}
      </main>
    </div>
  )
}
