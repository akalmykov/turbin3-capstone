"use client"

import { type FC, useState } from "react"
import { Heart, Droplet, Shield, Sparkles, ChevronDown, ChevronUp, ExternalLink, Zap } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface PlayersListProps {
  onPlayCard?: (playerId: string) => void
}

const PlayersList: FC<PlayersListProps> = ({ onPlayCard }) => {
  const [sortField, setSortField] = useState<string>("hp")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")

  // Mock player data - in a real app, you would fetch this from your backend
  const players = [
    { id: 1, address: "8xzt7...9j2k", hp: 120, mana: 80, armor: 35, magicalResistance: 20 },
    { id: 2, address: "3fgh5...1m4n", hp: 95, mana: 100, armor: 25, magicalResistance: 30 },
    { id: 3, address: "7pqr2...8s3t", hp: 150, mana: 60, armor: 40, magicalResistance: 15 },
    { id: 4, address: "5uvw9...2x7y", hp: 80, mana: 90, armor: 20, magicalResistance: 40 },
    { id: 5, address: "1abc4...6d2e", hp: 110, mana: 75, armor: 30, magicalResistance: 25 },
    { id: 6, address: "9fgh3...4j7k", hp: 130, mana: 85, armor: 15, magicalResistance: 35 },
    { id: 7, address: "2lmn8...5p1q", hp: 100, mana: 95, armor: 45, magicalResistance: 10 },
    { id: 8, address: "6rst7...3u9v", hp: 140, mana: 70, armor: 10, magicalResistance: 45 },
  ]

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("desc")
    }
  }

  const sortedPlayers = [...players].sort((a, b) => {
    const fieldA = a[sortField as keyof typeof a]
    const fieldB = b[sortField as keyof typeof b]

    if (sortDirection === "asc") {
      return fieldA > fieldB ? 1 : -1
    } else {
      return fieldA < fieldB ? 1 : -1
    }
  })

  const getSortIcon = (field: string) => {
    if (sortField !== field) return null
    return sortDirection === "asc" ? <ChevronUp className="ml-1 h-3 w-3" /> : <ChevronDown className="ml-1 h-3 w-3" />
  }

  return (
    <Card className="card-glow border-border/30 bg-card">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-light uppercase tracking-wider text-primary">Players</CardTitle>
      </CardHeader>
      <CardContent className="p-3">
        <div className="rounded-md border border-border/50 bg-secondary/30">
          <Table>
            <TableHeader>
              <TableRow className="border-border/50 hover:bg-secondary/50">
                <TableHead className="text-xs text-muted-foreground">Address</TableHead>
                <TableHead className="cursor-pointer text-xs text-muted-foreground" onClick={() => handleSort("hp")}>
                  <div className="flex items-center">
                    <Heart className="mr-1 h-3 w-3 text-[hsl(var(--hp-color))]" />
                    HP
                    {getSortIcon("hp")}
                  </div>
                </TableHead>
                <TableHead className="cursor-pointer text-xs text-muted-foreground" onClick={() => handleSort("mana")}>
                  <div className="flex items-center">
                    <Droplet className="mr-1 h-3 w-3 text-[hsl(var(--mana-color))]" />
                    MP
                    {getSortIcon("mana")}
                  </div>
                </TableHead>
                <TableHead className="cursor-pointer text-xs text-muted-foreground" onClick={() => handleSort("armor")}>
                  <div className="flex items-center">
                    <Shield className="mr-1 h-3 w-3 text-[hsl(var(--armor-color))]" />
                    AR
                    {getSortIcon("armor")}
                  </div>
                </TableHead>
                <TableHead
                  className="cursor-pointer text-xs text-muted-foreground"
                  onClick={() => handleSort("magicalResistance")}
                >
                  <div className="flex items-center">
                    <Sparkles className="mr-1 h-3 w-3 text-[hsl(var(--magic-resist-color))]" />
                    MR
                    {getSortIcon("magicalResistance")}
                  </div>
                </TableHead>
                <TableHead className="text-right text-xs text-muted-foreground">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedPlayers.map((player) => (
                <TableRow key={player.id} className="border-border/50 hover:bg-secondary/50">
                  <TableCell className="font-mono text-xs">{player.address}</TableCell>
                  <TableCell className="text-xs text-[hsl(var(--hp-color))]">{player.hp}</TableCell>
                  <TableCell className="text-xs text-[hsl(var(--mana-color))]">{player.mana}</TableCell>
                  <TableCell className="text-xs text-[hsl(var(--armor-color))]">{player.armor}</TableCell>
                  <TableCell className="text-xs text-[hsl(var(--magic-resist-color))]">
                    {player.magicalResistance}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 rounded-full p-0 text-muted-foreground hover:text-primary"
                      >
                        <ExternalLink className="h-3 w-3" />
                        <span className="sr-only">View more</span>
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onPlayCard && onPlayCard(player.address)}
                        className="h-7 border-border/50 bg-secondary px-2 py-0 text-xs text-primary hover:bg-secondary/80"
                      >
                        <Zap className="mr-1 h-3 w-3" />
                        Play
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

export default PlayersList
