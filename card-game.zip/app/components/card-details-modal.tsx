"use client"

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import Image from "next/image"
import { Droplet, X } from "lucide-react"
import { Button } from "@/components/ui/button"

interface CardDetailsModalProps {
  isOpen: boolean
  onClose: () => void
  card: {
    id: number
    name: string
    imageUrl: string
    description: string
    manaCost: number
    rarity: string
    type: string
    effects?: { name: string; description: string }[]
  } | null
}

const CardDetailsModal = ({ isOpen, onClose, card }: CardDetailsModalProps) => {
  if (!card) return null

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md border-border/30 bg-card p-0 text-card-foreground sm:max-w-lg">
        <Button
          variant="ghost"
          size="icon"
          className="absolute right-2 top-2 h-6 w-6 rounded-full bg-secondary/80 p-0 text-muted-foreground hover:bg-secondary hover:text-primary"
          onClick={onClose}
        >
          <X className="h-3 w-3" />
          <span className="sr-only">Close</span>
        </Button>

        <div className="grid grid-cols-1 sm:grid-cols-2">
          <div className="flex items-center justify-center bg-black/30 p-4">
            <div
              className={`relative overflow-hidden rounded-lg ${
                card.rarity === "legendary" ? "legendary-card" : card.rarity === "rare" ? "rare-card" : ""
              }`}
            >
              <Image
                src={card.imageUrl || "/placeholder.svg"}
                alt={card.name}
                width={200}
                height={280}
                className="h-full w-full object-cover"
              />
            </div>
          </div>

          <div className="flex flex-col p-4">
            <DialogHeader className="mb-2 pb-0">
              <DialogTitle className="text-lg font-light text-primary">{card.name}</DialogTitle>
              <DialogDescription className="text-xs text-muted-foreground">
                {card.type} • {card.rarity.charAt(0).toUpperCase() + card.rarity.slice(1)}
              </DialogDescription>
            </DialogHeader>

            <div className="flex items-center mb-4">
              <div className="stat-badge mana-badge">
                <Droplet className="mr-1 h-3 w-3" />
                <span>{card.manaCost}</span>
              </div>
            </div>

            <div className="mb-4">
              <h3 className="mb-1 text-xs font-light uppercase tracking-wider text-primary">Description</h3>
              <p className="text-sm text-muted-foreground">{card.description}</p>
            </div>

            {card.effects && card.effects.length > 0 && (
              <div>
                <h3 className="mb-1 text-xs font-light uppercase tracking-wider text-primary">Effects</h3>
                <ul className="space-y-2">
                  {card.effects.map((effect, index) => (
                    <li key={index} className="text-sm">
                      <span className="font-medium text-primary">{effect.name}:</span>{" "}
                      <span className="text-muted-foreground">{effect.description}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default CardDetailsModal
