"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, X, Droplet } from "lucide-react"
import Image from "next/image"
import { ScrollArea } from "@/components/ui/scroll-area"

interface CardSelectorModalProps {
  isOpen: boolean
  onClose: () => void
  onSelectCard: (cardId: number) => void
  targetName?: string
}

const CardSelectorModal = ({ isOpen, onClose, onSelectCard, targetName }: CardSelectorModalProps) => {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCardId, setSelectedCardId] = useState<number | null>(null)

  // Mock card data - in a real app, you would fetch this from your backend
  const playerCards = [
    {
      id: 1,
      name: "Fireball",
      imageUrl: "/placeholder.svg?height=120&width=90&text=Fireball",
      manaCost: 4,
      type: "Spell",
      rarity: "common",
    },
    {
      id: 2,
      name: "Ice Shield",
      imageUrl: "/placeholder.svg?height=120&width=90&text=Ice Shield",
      manaCost: 3,
      type: "Spell",
      rarity: "rare",
    },
    {
      id: 3,
      name: "Lightning Bolt",
      imageUrl: "/placeholder.svg?height=120&width=90&text=Lightning Bolt",
      manaCost: 2,
      type: "Spell",
      rarity: "common",
    },
    {
      id: 4,
      name: "Healing Potion",
      imageUrl: "/placeholder.svg?height=120&width=90&text=Healing Potion",
      manaCost: 5,
      type: "Item",
      rarity: "common",
    },
    {
      id: 5,
      name: "Dragon's Breath",
      imageUrl: "/placeholder.svg?height=120&width=90&text=Dragon's Breath",
      manaCost: 7,
      type: "Spell",
      rarity: "legendary",
    },
    {
      id: 6,
      name: "Mana Surge",
      imageUrl: "/placeholder.svg?height=120&width=90&text=Mana Surge",
      manaCost: 2,
      type: "Spell",
      rarity: "common",
    },
    {
      id: 7,
      name: "Mind Control",
      imageUrl: "/placeholder.svg?height=120&width=90&text=Mind Control",
      manaCost: 8,
      type: "Spell",
      rarity: "rare",
    },
    {
      id: 8,
      name: "Poison Dagger",
      imageUrl: "/placeholder.svg?height=120&width=90&text=Poison Dagger",
      manaCost: 3,
      type: "Weapon",
      rarity: "common",
    },
  ]

  const filteredCards = playerCards.filter((card) => card.name.toLowerCase().includes(searchTerm.toLowerCase()))

  const handleSelectCard = () => {
    if (selectedCardId !== null) {
      onSelectCard(selectedCardId)
      setSelectedCardId(null)
      setSearchTerm("")
    }
  }

  const handleClose = () => {
    setSelectedCardId(null)
    setSearchTerm("")
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && handleClose()}>
      <DialogContent className="max-w-2xl border-border/30 bg-card text-card-foreground">
        <DialogHeader>
          <DialogTitle className="text-sm font-light uppercase tracking-wider text-primary">
            Select Card {targetName ? `for ${targetName}` : ""}
          </DialogTitle>
        </DialogHeader>

        <div className="relative mb-4">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search cards..."
            className="border-border/50 bg-secondary pl-9 text-primary placeholder:text-muted-foreground"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {searchTerm && (
            <button
              className="absolute right-2.5 top-2.5 text-muted-foreground hover:text-primary"
              onClick={() => setSearchTerm("")}
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <ScrollArea className="h-[400px] pr-4">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
            {filteredCards.map((card) => (
              <div
                key={card.id}
                className={`card-hover relative cursor-pointer overflow-hidden rounded-lg bg-secondary transition-all duration-200 ${
                  selectedCardId === card.id ? "ring-1 ring-primary" : ""
                } ${card.rarity === "legendary" ? "legendary-card" : card.rarity === "rare" ? "rare-card" : ""}`}
                onClick={() => setSelectedCardId(card.id)}
              >
                <Image
                  src={card.imageUrl || "/placeholder.svg"}
                  alt={card.name}
                  width={90}
                  height={120}
                  className="h-full w-full object-cover"
                />
                <div className="absolute bottom-0 w-full bg-gradient-to-t from-black/90 via-black/60 to-transparent p-2">
                  <p className="text-xs font-medium text-white">{card.name}</p>
                  <div className="flex items-center justify-between">
                    <p
                      className={`text-xs ${
                        card.rarity === "legendary"
                          ? "text-[#ffd700]"
                          : card.rarity === "rare"
                            ? "text-[#1e90ff]"
                            : "text-muted-foreground"
                      }`}
                    >
                      {card.type}
                    </p>
                    <div className="stat-badge mana-badge text-[10px]">
                      <Droplet className="mr-0.5 h-2 w-2" />
                      <span>{card.manaCost}</span>
                    </div>
                  </div>
                </div>
                {selectedCardId === card.id && (
                  <div className="absolute left-0 top-0 h-full w-full border border-primary/50" />
                )}
              </div>
            ))}

            {filteredCards.length === 0 && (
              <div className="col-span-full py-8 text-center text-muted-foreground">
                No cards found matching "{searchTerm}"
              </div>
            )}
          </div>
        </ScrollArea>

        <div className="flex justify-end space-x-2">
          <Button variant="outline" onClick={handleClose} className="border-border/50 bg-secondary text-primary">
            Cancel
          </Button>
          <Button
            disabled={selectedCardId === null}
            onClick={handleSelectCard}
            className="bg-primary text-primary-foreground hover:bg-primary/90"
          >
            Play Card
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default CardSelectorModal
