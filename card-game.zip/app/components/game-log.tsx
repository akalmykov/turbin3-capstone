"use client"

import { type FC, useState } from "react"
import { ArrowUpDown, Filter, User, Target, Zap, Shield } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

const GameLog: FC = () => {
  const [sorting, setSorting] = useState<{ column: string | null; direction: "asc" | "desc" }>({
    column: "timestamp",
    direction: "desc",
  })

  const [filters, setFilters] = useState({
    showDamage: true,
    showBuffs: true,
    showDebuffs: true,
  })

  // Mock game log data - in a real app, you would fetch this from your backend
  const gameLogEntries = [
    {
      id: 1,
      timestamp: new Date(2023, 4, 10, 14, 30),
      player: "8xzt7...9j2k",
      target: "3fgh5...1m4n",
      card: "Fireball",
      damageDealt: 15,
      effects: [],
    },
    {
      id: 2,
      timestamp: new Date(2023, 4, 10, 14, 28),
      player: "3fgh5...1m4n",
      target: "8xzt7...9j2k",
      card: "Ice Shield",
      damageDealt: 0,
      effects: [{ type: "buff", name: "Armor +10", duration: "3 turns" }],
    },
    {
      id: 3,
      timestamp: new Date(2023, 4, 10, 14, 25),
      player: "7pqr2...8s3t",
      target: "5uvw9...2x7y",
      card: "Poison Dagger",
      damageDealt: 8,
      effects: [{ type: "debuff", name: "Poison", duration: "2 turns" }],
    },
    {
      id: 4,
      timestamp: new Date(2023, 4, 10, 14, 22),
      player: "5uvw9...2x7y",
      target: "Self",
      card: "Healing Potion",
      damageDealt: -20,
      effects: [],
    },
    {
      id: 5,
      timestamp: new Date(2023, 4, 10, 14, 20),
      player: "1abc4...6d2e",
      target: "9fgh3...4j7k",
      card: "Lightning Bolt",
      damageDealt: 25,
      effects: [],
    },
    {
      id: 6,
      timestamp: new Date(2023, 4, 10, 14, 18),
      player: "9fgh3...4j7k",
      target: "2lmn8...5p1q",
      card: "Mind Control",
      damageDealt: 0,
      effects: [{ type: "debuff", name: "Confused", duration: "1 turn" }],
    },
    {
      id: 7,
      timestamp: new Date(2023, 4, 10, 14, 15),
      player: "2lmn8...5p1q",
      target: "Self",
      card: "Mana Surge",
      damageDealt: 0,
      effects: [{ type: "buff", name: "Mana +30", duration: "Instant" }],
    },
  ]

  const handleSort = (column: string) => {
    setSorting({
      column,
      direction: sorting.column === column && sorting.direction === "asc" ? "desc" : "asc",
    })
  }

  const filteredEntries = gameLogEntries.filter((entry) => {
    if (!filters.showDamage && entry.damageDealt !== 0) return false
    if (!filters.showBuffs && entry.effects.some((e) => e.type === "buff")) return false
    if (!filters.showDebuffs && entry.effects.some((e) => e.type === "debuff")) return false
    return true
  })

  const sortedEntries = [...filteredEntries].sort((a, b) => {
    if (!sorting.column) return 0

    let valueA, valueB

    if (sorting.column === "timestamp") {
      valueA = a.timestamp.getTime()
      valueB = b.timestamp.getTime()
    } else {
      valueA = a[sorting.column as keyof typeof a]
      valueB = b[sorting.column as keyof typeof b]
    }

    const direction = sorting.direction === "asc" ? 1 : -1

    if (valueA < valueB) return -1 * direction
    if (valueA > valueB) return 1 * direction
    return 0
  })

  return (
    <Card className="card-glow border-border/30 bg-card">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-light uppercase tracking-wider text-primary">Game Log</CardTitle>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 rounded-full p-0 text-muted-foreground hover:text-primary"
            >
              <Filter className="h-3 w-3" />
              <span className="sr-only">Filter</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-[200px] border-border/50 bg-card">
            <DropdownMenuCheckboxItem
              checked={filters.showDamage}
              onCheckedChange={(checked) => setFilters({ ...filters, showDamage: checked })}
              className="text-xs"
            >
              Show Damage
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem
              checked={filters.showBuffs}
              onCheckedChange={(checked) => setFilters({ ...filters, showBuffs: checked })}
              className="text-xs"
            >
              Show Buffs
            </DropdownMenuCheckboxItem>
            <DropdownMenuCheckboxItem
              checked={filters.showDebuffs}
              onCheckedChange={(checked) => setFilters({ ...filters, showDebuffs: checked })}
              className="text-xs"
            >
              Show Debuffs
            </DropdownMenuCheckboxItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent className="p-3">
        <div className="rounded-md border border-border/50 bg-secondary/30">
          <Table>
            <TableHeader>
              <TableRow className="border-border/50 hover:bg-secondary/50">
                <TableHead
                  className="cursor-pointer text-xs text-muted-foreground"
                  onClick={() => handleSort("player")}
                >
                  <div className="flex items-center">
                    <User className="mr-1 h-3 w-3" />
                    Player
                    {sorting.column === "player" && <ArrowUpDown className="ml-1 h-3 w-3" />}
                  </div>
                </TableHead>
                <TableHead
                  className="cursor-pointer text-xs text-muted-foreground"
                  onClick={() => handleSort("target")}
                >
                  <div className="flex items-center">
                    <Target className="mr-1 h-3 w-3" />
                    Target
                    {sorting.column === "target" && <ArrowUpDown className="ml-1 h-3 w-3" />}
                  </div>
                </TableHead>
                <TableHead className="cursor-pointer text-xs text-muted-foreground" onClick={() => handleSort("card")}>
                  <div className="flex items-center">
                    <Zap className="mr-1 h-3 w-3" />
                    Card
                    {sorting.column === "card" && <ArrowUpDown className="ml-1 h-3 w-3" />}
                  </div>
                </TableHead>
                <TableHead
                  className="cursor-pointer text-xs text-muted-foreground"
                  onClick={() => handleSort("damageDealt")}
                >
                  <div className="flex items-center">
                    <Shield className="mr-1 h-3 w-3" />
                    Effect
                    {sorting.column === "damageDealt" && <ArrowUpDown className="ml-1 h-3 w-3" />}
                  </div>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedEntries.map((entry) => (
                <TableRow key={entry.id} className="border-border/50 hover:bg-secondary/50">
                  <TableCell className="font-mono text-xs">{entry.player}</TableCell>
                  <TableCell className="text-xs">{entry.target}</TableCell>
                  <TableCell className="text-xs">{entry.card}</TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1">
                      {entry.damageDealt !== 0 && (
                        <span
                          className={`text-xs ${
                            entry.damageDealt > 0 ? "text-[hsl(var(--hp-color))]" : "text-[#4ade80]"
                          }`}
                        >
                          {entry.damageDealt > 0
                            ? `${entry.damageDealt} damage`
                            : `${Math.abs(entry.damageDealt)} heal`}
                        </span>
                      )}

                      {entry.effects.map((effect, idx) => (
                        <span
                          key={idx}
                          className={`inline-flex rounded-full px-1.5 py-0.5 text-[10px] ${
                            effect.type === "buff" ? "bg-[#4ade80]/10 text-[#4ade80]" : "bg-[#f87171]/10 text-[#f87171]"
                          }`}
                        >
                          {effect.name} ({effect.duration})
                        </span>
                      ))}

                      {entry.damageDealt === 0 && entry.effects.length === 0 && (
                        <span className="text-xs text-muted-foreground">No effect</span>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}

export default GameLog
