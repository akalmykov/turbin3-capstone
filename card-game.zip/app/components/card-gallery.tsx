"use client"

import type { FC } from "react"
import { useState } from "react"
import Image from "next/image"
import CardDetailsModal from "./card-details-modal"
import { Droplet } from "lucide-react"

interface CardGalleryProps {
  showAll?: boolean
}

const CardGallery: FC<CardGalleryProps> = ({ showAll = false }) => {
  const [selectedCard, setSelectedCard] = useState<any | null>(null)
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false)

  // Mock card data - in a real app, you would fetch this from your backend
  const generateCards = (count: number) => {
    return Array.from({ length: count }, (_, i) => {
      const id = i + 1
      const rarity = i % 5 === 0 ? "legendary" : i % 3 === 0 ? "rare" : "common"
      const manaCost = Math.floor(Math.random() * 8) + 1
      const types = ["Spell", "Creature", "Artifact", "Weapon", "Item"]
      const type = types[Math.floor(Math.random() * types.length)]

      return {
        id,
        name: `Card ${id}`,
        imageUrl: `/placeholder.svg?height=200&width=150&text=Card ${id}`,
        rarity,
        manaCost,
        type,
        description: `This is a ${rarity} ${type.toLowerCase()} card that costs ${manaCost} mana to play.`,
        effects:
          rarity !== "common"
            ? [
                { name: "Primary Effect", description: "Does something awesome when played." },
                { name: "Secondary Effect", description: "Has an additional effect under certain conditions." },
              ]
            : undefined,
      }
    })
  }

  const allCards = generateCards(showAll ? 100 : 25)
  const displayedCards = showAll ? allCards : allCards.slice(0, 25)

  const handleCardClick = (card: any) => {
    setSelectedCard(card)
    setIsDetailsModalOpen(true)
  }

  return (
    <div className="space-y-4">
      <h2 className="text-sm font-light uppercase tracking-wider text-primary">
        {showAll ? "All Cards" : "Latest Cards"}
      </h2>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
        {displayedCards.map((card) => (
          <div
            key={card.id}
            className={`card-hover relative cursor-pointer overflow-hidden rounded-lg bg-card ${
              card.rarity === "legendary" ? "legendary-card" : card.rarity === "rare" ? "rare-card" : "card-glow"
            }`}
            onClick={() => handleCardClick(card)}
          >
            <Image
              src={card.imageUrl || "/placeholder.svg"}
              alt={card.name}
              width={150}
              height={200}
              className="h-full w-full object-cover"
            />
            <div className="absolute bottom-0 w-full bg-gradient-to-t from-black/90 via-black/60 to-transparent p-2">
              <p className="text-xs font-medium text-white">{card.name}</p>
              <div className="flex items-center justify-between">
                <p
                  className={`text-xs ${
                    card.rarity === "legendary"
                      ? "text-[#ffd700]"
                      : card.rarity === "rare"
                        ? "text-[#1e90ff]"
                        : "text-muted-foreground"
                  }`}
                >
                  {card.type}
                </p>
                <div className="stat-badge mana-badge text-[10px]">
                  <Droplet className="mr-0.5 h-2 w-2" />
                  {card.manaCost}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {!showAll && displayedCards.length >= 25 && (
        <div className="flex justify-center">
          <p className="text-xs text-muted-foreground">Showing the 25 most recent cards</p>
        </div>
      )}

      <CardDetailsModal isOpen={isDetailsModalOpen} onClose={() => setIsDetailsModalOpen(false)} card={selectedCard} />
    </div>
  )
}

export default CardGallery
