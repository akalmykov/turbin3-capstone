import type { FC } from "react"
import { Shield, Heart, Droplet, Sparkles, User } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface UserInfoProps {
  publicKey: string
}

const UserInfo: FC<UserInfoProps> = ({ publicKey }) => {
  // Mock user data - in a real app, you would fetch this from your backend
  const userData = {
    hp: 100,
    mana: 75,
    armor: 30,
    magicalResistance: 25,
    buffs: [
      { id: 1, name: "Strength", duration: "2 turns", type: "buff" },
      { id: 2, name: "Haste", duration: "3 turns", type: "buff" },
    ],
    debuffs: [{ id: 3, name: "Poison", duration: "1 turn", type: "debuff" }],
  }

  return (
    <Card className="card-glow border-border/30 bg-card">
      <CardContent className="p-4">
        <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary">
              <User className="h-4 w-4 text-primary" />
            </div>
            <div>
              <h2 className="text-sm font-light uppercase tracking-wider text-primary">Player</h2>
              <p className="text-xs text-muted-foreground">
                <span className="font-mono">
                  {publicKey.slice(0, 6)}...{publicKey.slice(-4)}
                </span>
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-3">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="stat-badge hp-badge">
                    <Heart className="mr-1 h-3 w-3" />
                    <span>{userData.hp}</span>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Health Points</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="stat-badge mana-badge">
                    <Droplet className="mr-1 h-3 w-3" />
                    <span>{userData.mana}</span>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Mana Points</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="stat-badge armor-badge">
                    <Shield className="mr-1 h-3 w-3" />
                    <span>{userData.armor}</span>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Armor Points</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="stat-badge magic-badge">
                    <Sparkles className="mr-1 h-3 w-3" />
                    <span>{userData.magicalResistance}</span>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Magical Resistance</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>

        <div className="mt-4">
          <h3 className="mb-2 text-xs font-light uppercase tracking-wider text-primary">Effects:</h3>
          <div className="flex flex-wrap gap-2">
            {userData.buffs.map((buff) => (
              <Badge key={buff.id} variant="outline" className="border-[#4ade80]/30 bg-[#4ade80]/5 text-[#4ade80]">
                {buff.name} ({buff.duration})
              </Badge>
            ))}
            {userData.debuffs.map((debuff) => (
              <Badge key={debuff.id} variant="outline" className="border-[#f87171]/30 bg-[#f87171]/5 text-[#f87171]">
                {debuff.name} ({debuff.duration})
              </Badge>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default UserInfo
